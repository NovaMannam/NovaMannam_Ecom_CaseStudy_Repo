package com.ecom.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ecom.entity.Customer;
import com.ecom.entity.Product;
import com.ecom.util.DBUtil;

public class CartDAOImpl implements ICartDAO {

	@Override
	public boolean addToCart(Customer customer, Product product, int quantity)
			throws ClassNotFoundException, SQLException {
		try (Connection connection = DBUtil.createConnection()) {
			// Check if the product is already in the cart for the customer
			if (isProductInCart(connection, customer, product)) {
				// You may choose to update the quantity here
				return false;
			}

			String sql = "INSERT INTO cart (customer_id, product_id, quantity) VALUES (?, ?, ?)";
			try (PreparedStatement statement = connection.prepareStatement(sql)) {
				statement.setInt(1, customer.getCustomerId());
				statement.setInt(2, product.getProductId());
				statement.setInt(3, quantity);

				int rowsInserted = statement.executeUpdate();
				return rowsInserted > 0;
			}
		}
	}

	@Override
	public boolean removeFromCart(Customer customer, Product product) throws ClassNotFoundException, SQLException {
		try (Connection connection = DBUtil.createConnection()) {
			// Check if the product is in the cart for the customer
			if (!isProductInCart(connection, customer, product)) {
				return false; // Product is not in the cart
			}

			String sql = "DELETE FROM cart WHERE customer_id = ? AND product_id = ?";
			try (PreparedStatement statement = connection.prepareStatement(sql)) {
				statement.setInt(1, customer.getCustomerId());
				statement.setInt(2, product.getProductId());

				int rowsDeleted = statement.executeUpdate();
				return rowsDeleted > 0;
			}
		}
	}

	@Override
	public List<Product> getAllFromCart(Customer customer) throws ClassNotFoundException, SQLException {
		try (Connection connection = DBUtil.createConnection()) {
			String sql = "select c.customer_id, p.product_id,p.name,p.price,p.description,crt.quantity from product p "
					+ "join cart crt using(product_id) "
					+ "join customer c using(customer_id) "
					+ "where customer_id = ?";
			
			try (PreparedStatement statement = connection.prepareStatement(sql)) {
				statement.setInt(1, customer.getCustomerId());

				try (ResultSet resultSet = statement.executeQuery()) {
					List<Product> productList = new ArrayList<>();
					while (resultSet.next()) {
						Product product = new Product();
						product.setProductId(resultSet.getInt("p.product_id"));
						product.setName(resultSet.getString("p.name"));
						product.setPrice(resultSet.getDouble("p.price"));
						product.setDescription(resultSet.getString("p.description"));
						product.setStockQuantity(resultSet.getInt("crt.quantity"));

						productList.add(product);
					}
					return productList;
				}
			}
		}
	}

	private boolean isProductInCart(Connection connection, Customer customer, Product product) throws SQLException {
		String sql = "SELECT * FROM cart WHERE customer_id = ? AND product_id = ?";
		try (PreparedStatement statement = connection.prepareStatement(sql)) {
			statement.setInt(1, customer.getCustomerId());
			statement.setInt(2, product.getProductId());

			try (ResultSet resultSet = statement.executeQuery()) {
				return resultSet.next();
			}
		}
	}

}
