package com.ecom.dao;

import java.sql.SQLException;
import java.util.List;

import com.ecom.entity.Customer;
import com.ecom.entity.Product;

public interface ICartDAO {

	boolean addToCart(Customer customer, Product product, int quantity) throws ClassNotFoundException, SQLException;

	boolean removeFromCart(Customer customer, Product product) throws ClassNotFoundException, SQLException;

	List<Product> getAllFromCart(Customer customer) throws ClassNotFoundException, SQLException;
}
