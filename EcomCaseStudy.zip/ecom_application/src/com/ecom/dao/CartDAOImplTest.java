package com.ecom.dao;

import static org.junit.Assert.assertTrue;

import java.sql.SQLException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ecom.entity.Customer;
import com.ecom.entity.Product;

public class CartDAOImplTest {

	private ICartDAO cartDAO;
	private ICustomerDAO customerDAO;
	private IProductDAO productDAO;

	@Before
	public void setUp() throws Exception {
		cartDAO = new CartDAOImpl();
		customerDAO = new CustomerDAOImpl();
		productDAO = new ProductDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		cartDAO = null;
		customerDAO = null;
		productDAO = null;
	}

	@Test
	public final void testProductAddedToCartSuccessfully() {
		Customer customer = new Customer("Jack", "jack@gmail.com", "jack123");

		Product product = new Product("Smartphone", 800.00, "Latest smartphone model", 10);

		boolean addedToCartSuccessfully = false;

		try {
			customerDAO.createCustomer(customer);
			productDAO.createProduct(product);

			addedToCartSuccessfully = cartDAO.addToCart(customer, product, 2); // Add 2 smartphones to the cart

		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username, or password is wrong or duplicate record");
			se.printStackTrace();
		}

		assertTrue("Product should be added to the cart successfully", addedToCartSuccessfully);
	}
}
