package com.ecom.service;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ecom.entity.Customer;

public class CustomerServiceImplTest {
	private static ICustomerService customerservice;

	@Before
	public void setUp() throws Exception {
		customerservice = new CustomerServiceImpl();
	}

	@After
	public void tearDown() throws Exception {
		customerservice = null;
	}

	@Test
	public void testCreateCustomer() {
		Customer customer = new Customer("customer2", "customer2@gmail.com", "1234567");
		boolean result = customerservice.createCustomer(customer);
		assertTrue(result);

	}

	@Test
	public void testDeleteCustomer() {
		int customerid = 1;
		boolean result = customerservice.deleteCustomer(customerid);
		if (result) {
			assertTrue(result);
		} else {
			assertFalse("Customer Not Found :", result);
		}

	}

	@Test
	public void testViewCustomer() {
		int customerid = 2;
		Customer customer = null;
		customer = customerservice.viewCustomer(customerid);
		assertNotNull(customer);
	}

	@Test
	public void testViewCustomers() {
		List<Customer> customerList = null;
		customerList = customerservice.viewCustomers();
		assertTrue("Customer should not be null :", customerList != null);
	}

	@Test
	public void testUpdateCustomer() {
		int customerid = 2;
		Customer customer = new Customer(customerid, "newName", "newEMail", "newPassword");
		boolean result = customerservice.updateCustomer(customer);
		if (result) {
			assertTrue(result);
		} else {
			assertFalse(result);
		}

	}

}
