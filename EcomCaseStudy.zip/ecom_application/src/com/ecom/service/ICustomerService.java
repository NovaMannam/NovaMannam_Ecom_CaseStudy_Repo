package com.ecom.service;

import java.util.List;

import com.ecom.entity.Customer;

public interface ICustomerService {

	public boolean createCustomer(Customer customer);

	public boolean deleteCustomer(int customerId);

	public Customer viewCustomer(int customerId);

	public List<Customer> viewCustomers();
	
	public boolean updateCustomer(Customer customer);
}