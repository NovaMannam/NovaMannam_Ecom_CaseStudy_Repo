package com.ecom.service;

import java.sql.SQLException;
import java.util.List;

import com.ecom.dao.IProductDAO;
import com.ecom.dao.ProductDAOImpl;
import com.ecom.entity.Product;
import com.ecom.exception.ProductNotFoundException;

public class ProductServiceImpl implements IProductService {

	private IProductDAO iProductDAO;

    public ProductServiceImpl() {
    	super();
        this.iProductDAO = new ProductDAOImpl();
    }

    @Override
    public boolean createProduct(Product product) {
    	boolean result = false;
		try {
			result = iProductDAO.createProduct(product);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		}
		return result;
    }

    @Override
    public boolean deleteProduct(int productId) {
    	boolean result = false;
		try {
			result = iProductDAO.deleteProduct(productId);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (ProductNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}

		return result;
    }

    @Override
    public Product viewProduct(int productId) {
    	Product product = null;

		try {
			product = iProductDAO.viewProduct(productId);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (ProductNotFoundException pnfe) {
			System.out.println(pnfe.getMessage());
		}

		return product;
    }

    @Override
    public List<Product> viewProducts() {
    	List<Product> productList = null;

		try {
			productList = iProductDAO.viewProducts();
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (ProductNotFoundException pnfe) {
			System.out.println(pnfe.getMessage());
		}
		return productList;
    }
}
